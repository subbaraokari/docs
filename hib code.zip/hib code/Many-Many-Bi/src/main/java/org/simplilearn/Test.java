package org.simplilearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.config.HibConfig;
import org.simplilearn.entities.Course;
import org.simplilearn.entities.Student;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Student st1=new Student();
			st1.setName("Ram");
			st1.setAddress("Chennai");
			Student st2=new Student();
			st2.setName("Arun");
			st2.setAddress("Chennai");
			Course c1=new Course();
			c1.setCourseName("java");
			c1.setFee(100);
			st1.addCourse(c1);
			st2.addCourse(c1);
			c1.addStudent(st1);
			c1.addStudent(st2);
			session.save(c1);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

}
