package org.simplilearn.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.simplilearn.config.HibConfig;
import org.simplilearn.entities.Emp;

public class EmpDaoHibernateImpl implements EmpDao{

	@Override
	public void insert(Emp e) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(e);
			tx.commit();
		} catch (Exception e2) {
			tx.rollback();
			e2.printStackTrace();
		}
		session.close();
	}

	@Override
	public void delete(int eno) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Emp e=session.get(Emp.class, eno);
			session.delete(e);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public Emp get(int eno) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Emp e=session.get(Emp.class, eno);
		return e;
	}

	@Override
	public List<Emp> getAll() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Criteria criteria=session.createCriteria(Emp.class);
		Criterion addressCriterion=Restrictions.like("address", "Chennai");
		Criterion enoCriterion=Restrictions.like("eno", 1);
		criteria.add(addressCriterion);
		criteria.add(enoCriterion);
		return criteria.list();
	}

	@Override
	public void update(int eno, Emp e) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Emp e1=session.get(Emp.class, eno);
			e1.setName(e.getName());
			e1.setAddress(e.getAddress());
			session.save(e1);
			tx.commit();
		} catch (Exception e2) {
			tx.rollback();
			e2.printStackTrace();
		}
	}

}
