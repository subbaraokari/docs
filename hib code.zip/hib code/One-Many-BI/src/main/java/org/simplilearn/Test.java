package org.simplilearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.config.HibConfig;
import org.simplilearn.entities.Account;
import org.simplilearn.entities.Person;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory = HibConfig.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx=session.beginTransaction();
			Account acct1 = new Account();
			acct1.setAcctNo("2336236232");
			acct1.setBankName("ABC");
			Account acct2 = new Account();
			acct1.setAcctNo("23362343436232");
			acct1.setBankName("XYZ");
			Person person = new Person();
			person.setName("suresh");
			person.setAddress("Chennai");
			person.addAccount(acct1);
			person.addAccount(acct2);
			acct1.setPerson(person);
			acct2.setPerson(person);
			session.save(acct1);
			session.save(acct2);
			session.save(person);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}

	}

}
